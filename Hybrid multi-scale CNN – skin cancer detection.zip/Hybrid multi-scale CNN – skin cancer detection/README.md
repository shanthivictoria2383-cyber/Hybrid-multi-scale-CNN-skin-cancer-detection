# Hybrid Multi-Scale Deep Learning Framework for Skin Cancer Detection
### Using Dermoscopic Images (HAM10000 / ISIC Dataset)

> **PhD Core Paper 3** — Q1 Journal Implementation  
> Architecture: Multi-scale input → Parallel CNN → Attention Feature Fusion → Classification

---

## 📁 Project Structure

```
skin_cancer_detection/
├── data/
│   ├── download_dataset.py     # Kaggle downloader + organizer
│   ├── dataset.py              # Multi-scale dataset class & dataloaders
│   ├── raw/                    # Downloaded raw HAM10000 images
│   └── processed/              # Class-organized images
│       ├── Melanoma/
│       ├── Melanocytic_Nevi/
│       ├── Basal_Cell_Carcinoma/
│       ├── Actinic_Keratosis/
│       ├── Benign_Keratosis/
│       ├── Dermatofibroma/
│       └── Vascular_Lesion/
├── models/
│   └── hybrid_multiscale_cnn.py  # Full model architecture
├── utils/
│   ├── gradcam.py               # GradCAM explainability
│   └── plot_training.py         # Training curve plots
├── checkpoints/                 # Saved model weights
├── results/                     # Metrics, plots, predictions
├── logs/                        # TensorBoard logs
├── train.py                     # Training pipeline
├── evaluate.py                  # Full evaluation + visualizations
├── predict.py                   # Real-time single/batch prediction
└── requirements.txt
```

---

## 🏗️ Model Architecture

```
Input Images (3 scales)
      │
  ┌───┴──────────────────────────────┐
  │                                  │
128×128             224×224        320×320
EfficientNet-B0  EfficientNet-B2  EfficientNet-B4
  │                   │               │
512-dim feat       512-dim feat   512-dim feat
  └───────────────────┴───────────────┘
                       │
            Attention Feature Fusion
            (Scale-wise + Channel Attn)
                       │
                  512-dim vector
                       │
              Classification Head
              (256 → 128 → 7 classes)
                       │
                  Output Logits
```

**Key innovations:**
- **Multi-scale inputs**: Captures both fine-grained texture (small scale) and global context (large scale)
- **Heterogeneous backbones**: Each scale uses an appropriately-sized EfficientNet
- **Dual attention fusion**: Scale-level softmax attention + SE-style channel attention
- **Class-balanced training**: Weighted random sampling + Focal Loss for HAM10000 imbalance

---

## ⚙️ Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup Kaggle API
```bash
# Place your kaggle.json at ~/.kaggle/kaggle.json
# Get it from: https://www.kaggle.com/account → Create New API Token
chmod 600 ~/.kaggle/kaggle.json
```

### 3. Download & prepare dataset
```bash
python data/download_dataset.py
```

---

## 🚀 Training

```bash
# Standard training (GPU recommended)
python train.py \
  --data_dir data/processed \
  --epochs 50 \
  --batch_size 32 \
  --lr 1e-3 \
  --patience 10

# Monitor with TensorBoard
tensorboard --logdir logs/
```

**Training features:**
- Mixed precision (FP16) on CUDA GPUs
- Cosine Annealing with Warm Restarts LR schedule
- Differential learning rates (backbone 10× lower than head)
- Gradient clipping (max_norm=1.0)
- Early stopping with patience
- Best model auto-saved to `checkpoints/best_model.pth`

---

## 📊 Evaluation

```bash
python evaluate.py \
  --data_dir data/processed \
  --checkpoint checkpoints/best_model.pth
```

**Outputs in `results/`:**
- `confusion_matrix.png` — Raw + normalized confusion matrices
- `roc_curves.png` — Per-class ROC curves with AUC
- `per_class_metrics.png` — Precision, Recall, F1 per class
- `classification_report.txt` — Full sklearn report
- `training_curves.png` — Loss/Accuracy/F1/AUC curves

---

## 🔍 Real-time Prediction

```bash
# Single image
python predict.py \
  --image path/to/lesion.jpg \
  --checkpoint checkpoints/best_model.pth

# Folder of images
python predict.py \
  --folder path/to/images/ \
  --checkpoint checkpoints/best_model.pth
```

---

## 🧠 GradCAM Explainability

```bash
python utils/gradcam.py \
  --image path/to/lesion.jpg \
  --checkpoint checkpoints/best_model.pth \
  --save results/gradcam_output.png
```

Shows attention heatmaps for all 3 scale branches — reveals what each scale "sees".

---

## 📈 Expected Results (HAM10000)

| Metric    | Expected      |
|-----------|---------------|
| Accuracy  | ~89–92%       |
| Precision | ~88–91%       |
| Recall    | ~87–90%       |
| F1 Score  | ~88–91%       |
| ROC-AUC   | ~0.95–0.97    |

*Results vary based on hardware, training duration, and augmentation settings.*

---

## 📋 Classes

| Code  | Class Name              | Risk Level  |
|-------|-------------------------|-------------|
| mel   | Melanoma                | 🔴 HIGH     |
| bcc   | Basal Cell Carcinoma    | 🔴 HIGH     |
| akiec | Actinic Keratosis       | 🟠 MEDIUM   |
| nv    | Melanocytic Nevi        | 🟢 LOW      |
| bkl   | Benign Keratosis        | 🟢 LOW      |
| df    | Dermatofibroma          | 🟢 LOW      |
| vasc  | Vascular Lesion         | 🟠 MEDIUM   |

---

## ⚠️ Disclaimer

This tool is developed for **academic research purposes only**.  
It is **not a medical device** and should not be used for clinical diagnosis.  
Always consult a qualified dermatologist for skin lesion evaluation.

---

## 📚 Citation

If you use this work, please cite:

```bibtex
@article{hybrid_multiscale_skin_2025,
  title   = {Hybrid Multi-Scale Deep Learning Framework for Accurate Skin Cancer Detection Using Dermoscopic Images},
  author  = {[Your Name]},
  journal = {[Target Q1 Journal]},
  year    = {2025},
}
```
