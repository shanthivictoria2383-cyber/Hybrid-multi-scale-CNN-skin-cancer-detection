# skin_cancer_detection package
