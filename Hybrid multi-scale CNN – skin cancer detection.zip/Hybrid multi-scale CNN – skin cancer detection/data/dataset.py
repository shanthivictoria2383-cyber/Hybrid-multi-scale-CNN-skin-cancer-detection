"""
data/dataset.py
HAM10000 Dataset class with multi-scale support and augmentations.
"""

import os
import numpy as np
import pandas as pd
from PIL import Image
from pathlib import Path
from typing import Tuple, List, Optional, Dict

import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from torchvision import transforms
import albumentations as A
from albumentations.pytorch import ToTensorV2
from sklearn.model_selection import train_test_split


# HAM10000 class labels
CLASSES = [
    "Melanoma",
    "Melanocytic_Nevi",
    "Basal_Cell_Carcinoma",
    "Actinic_Keratosis",
    "Benign_Keratosis",
    "Dermatofibroma",
    "Vascular_Lesion",
]
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}
IDX_TO_CLASS = {i: c for c, i in CLASS_TO_IDX.items()}

# Multi-scale image sizes (small, medium, large)
SCALES = [128, 224, 320]


def get_train_transforms(size: int) -> A.Compose:
    return A.Compose([
        A.RandomResizedCrop(height=size, width=size, scale=(0.8, 1.0)),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.1, rotate_limit=30, p=0.5),
        A.OneOf([
            A.ElasticTransform(p=1),
            A.GridDistortion(p=1),
            A.OpticalDistortion(p=1),
        ], p=0.3),
        A.OneOf([
            A.GaussNoise(p=1),
            A.GaussianBlur(p=1),
            A.MotionBlur(p=1),
        ], p=0.3),
        A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1, p=0.5),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])


def get_val_transforms(size: int) -> A.Compose:
    return A.Compose([
        A.Resize(height=size, width=size),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])


class HAM10000Dataset(Dataset):
    """
    Multi-scale HAM10000 dataset.
    Returns 3 image tensors at different scales for the hybrid model.
    """

    def __init__(
        self,
        image_paths: List[str],
        labels: List[int],
        scales: List[int] = SCALES,
        mode: str = "train",
    ):
        self.image_paths = image_paths
        self.labels = labels
        self.scales = scales
        self.mode = mode

        # Build transforms for each scale
        if mode == "train":
            self.transforms = [get_train_transforms(s) for s in scales]
        else:
            self.transforms = [get_val_transforms(s) for s in scales]

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tuple[List[torch.Tensor], int]:
        img_path = self.image_paths[idx]
        label = self.labels[idx]

        image = np.array(Image.open(img_path).convert("RGB"))

        # Apply transforms at each scale independently (same augmentation seed)
        multi_scale_imgs = []
        for tf in self.transforms:
            augmented = tf(image=image)["image"]
            multi_scale_imgs.append(augmented)

        return multi_scale_imgs, label


def build_dataloaders(
    data_dir: str,
    batch_size: int = 32,
    val_split: float = 0.15,
    test_split: float = 0.15,
    num_workers: int = 4,
    scales: List[int] = SCALES,
    seed: int = 42,
) -> Dict[str, DataLoader]:
    """
    Scans data_dir (organized as class folders), splits into train/val/test,
    applies class-balanced sampling for training.
    """
    data_dir = Path(data_dir)
    image_paths, labels = [], []

    for class_name in CLASSES:
        class_dir = data_dir / class_name
        if not class_dir.exists():
            continue
        for img_file in class_dir.glob("*.jpg"):
            image_paths.append(str(img_file))
            labels.append(CLASS_TO_IDX[class_name])

    print(f"Total images found: {len(image_paths)}")

    # Stratified split
    X_train, X_temp, y_train, y_temp = train_test_split(
        image_paths, labels, test_size=(val_split + test_split),
        stratify=labels, random_state=seed
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=test_split / (val_split + test_split),
        stratify=y_temp, random_state=seed
    )

    print(f"Train: {len(X_train)} | Val: {len(X_val)} | Test: {len(X_test)}")

    # Class-balanced sampler for training
    class_counts = np.bincount(y_train)
    class_weights = 1.0 / class_counts
    sample_weights = [class_weights[y] for y in y_train]
    sampler = WeightedRandomSampler(
        weights=sample_weights, num_samples=len(sample_weights), replacement=True
    )

    def collate_fn(batch):
        imgs_list, labels_list = zip(*batch)
        # imgs_list: list of [scale0, scale1, scale2] per sample
        scales_batched = []
        for s in range(len(scales)):
            scales_batched.append(torch.stack([imgs[s] for imgs in imgs_list]))
        return scales_batched, torch.tensor(labels_list, dtype=torch.long)

    train_ds = HAM10000Dataset(X_train, y_train, scales=scales, mode="train")
    val_ds   = HAM10000Dataset(X_val,   y_val,   scales=scales, mode="val")
    test_ds  = HAM10000Dataset(X_test,  y_test,  scales=scales, mode="test")

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, sampler=sampler,
        num_workers=num_workers, pin_memory=True, collate_fn=collate_fn
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True, collate_fn=collate_fn
    )
    test_loader = DataLoader(
        test_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True, collate_fn=collate_fn
    )

    return {
        "train": train_loader,
        "val": val_loader,
        "test": test_loader,
        "class_weights": torch.tensor(class_weights, dtype=torch.float32),
        "num_classes": len(CLASSES),
    }
