"""
data/download_dataset.py
Downloads HAM10000 dataset from Kaggle and prepares directory structure.
Run: python data/download_dataset.py
Requires: kaggle API key at ~/.kaggle/kaggle.json
"""

import os
import zipfile
import shutil
import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).parent
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"


def download_ham10000():
    """Download HAM10000 from Kaggle."""
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    print("Downloading HAM10000 dataset from Kaggle...")
    os.system(
        f"kaggle datasets download -d kmader/skin-lesion-analysis-toward-melanoma-detection "
        f"--path {RAW_DIR} --unzip"
    )
    print("Download complete.")


def organize_images():
    """Organize images into class-based folders for ImageFolder compatibility."""
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

    # Find the metadata CSV
    csv_candidates = list(RAW_DIR.rglob("HAM10000_metadata.csv"))
    if not csv_candidates:
        raise FileNotFoundError("HAM10000_metadata.csv not found. Check download.")
    df = pd.read_csv(csv_candidates[0])

    # Collect all images
    all_images = {p.stem: p for p in RAW_DIR.rglob("*.jpg")}
    print(f"Found {len(all_images)} images, {len(df)} metadata rows.")

    label_map = {
        "mel": "Melanoma",
        "nv": "Melanocytic_Nevi",
        "bcc": "Basal_Cell_Carcinoma",
        "akiec": "Actinic_Keratosis",
        "bkl": "Benign_Keratosis",
        "df": "Dermatofibroma",
        "vasc": "Vascular_Lesion",
    }

    missing = 0
    for _, row in df.iterrows():
        image_id = row["image_id"]
        label = label_map.get(row["dx"], "Unknown")
        dest_dir = PROCESSED_DIR / label
        dest_dir.mkdir(parents=True, exist_ok=True)

        src = all_images.get(image_id)
        if src:
            shutil.copy(src, dest_dir / f"{image_id}.jpg")
        else:
            missing += 1

    print(f"Organized images. Missing: {missing}")
    print(f"Classes: {list(label_map.values())}")
    print(f"Processed data at: {PROCESSED_DIR}")


def print_class_distribution():
    """Print class counts after organization."""
    if not PROCESSED_DIR.exists():
        print("Run organize_images() first.")
        return
    print("\nClass Distribution:")
    print("-" * 40)
    total = 0
    for cls_dir in sorted(PROCESSED_DIR.iterdir()):
        if cls_dir.is_dir():
            count = len(list(cls_dir.glob("*.jpg")))
            total += count
            print(f"  {cls_dir.name:<30} {count:>5}")
    print(f"  {'TOTAL':<30} {total:>5}")


if __name__ == "__main__":
    download_ham10000()
    organize_images()
    print_class_distribution()
