"""
evaluate.py
Full evaluation: confusion matrix, per-class metrics, ROC curves, GradCAM.

Usage:
    python evaluate.py --data_dir data/processed --checkpoint checkpoints/best_model.pth
"""

import argparse
import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path

import torch
import torch.nn.functional as F
from tqdm import tqdm
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_curve, auc
)
from sklearn.preprocessing import label_binarize

from data.dataset import build_dataloaders, CLASSES, IDX_TO_CLASS
from models.hybrid_multiscale_cnn import build_model


def load_model(checkpoint_path, device, num_classes=7):
    model = build_model(num_classes=num_classes, pretrained=False).to(device)
    ckpt  = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    print(f"Loaded model from {checkpoint_path} (epoch {ckpt['epoch']})")
    return model


def run_inference(model, loader, device):
    all_preds, all_labels, all_probs = [], [], []
    with torch.no_grad():
        for x_list, labels in tqdm(loader, desc="Evaluating"):
            x_list = [x.to(device) for x in x_list]
            logits = model(x_list)
            probs  = F.softmax(logits, dim=-1)
            preds  = torch.argmax(probs, dim=-1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.numpy())
            all_probs.extend(probs.cpu().numpy())
    return np.array(all_preds), np.array(all_labels), np.array(all_probs)


def plot_confusion_matrix(labels, preds, save_path):
    cm = confusion_matrix(labels, preds)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)

    short_names = [c.replace("_", "\n") for c in CLASSES]
    fig, axes = plt.subplots(1, 2, figsize=(18, 7))

    for ax, data, title, fmt in zip(
        axes,
        [cm, cm_norm],
        ["Confusion Matrix (Counts)", "Confusion Matrix (Normalized)"],
        ["d", ".2f"]
    ):
        sns.heatmap(
            data, annot=True, fmt=fmt, cmap="Blues",
            xticklabels=short_names, yticklabels=short_names, ax=ax,
            linewidths=0.5
        )
        ax.set_title(title, fontsize=13, fontweight="bold")
        ax.set_xlabel("Predicted", fontsize=11)
        ax.set_ylabel("True", fontsize=11)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {save_path}")


def plot_roc_curves(labels, probs, save_path):
    y_bin = label_binarize(labels, classes=list(range(len(CLASSES))))
    fig, ax = plt.subplots(figsize=(10, 8))

    colors = plt.cm.tab10(np.linspace(0, 1, len(CLASSES)))
    for i, (cls, color) in enumerate(zip(CLASSES, colors)):
        fpr, tpr, _ = roc_curve(y_bin[:, i], probs[:, i])
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=color, lw=1.8,
                label=f"{cls.replace('_', ' ')} (AUC={roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random (AUC=0.500)")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curves – Per Class (One-vs-Rest)", fontsize=14, fontweight="bold")
    ax.legend(loc="lower right", fontsize=9)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {save_path}")


def plot_per_class_metrics(labels, preds, save_path):
    report = classification_report(
        labels, preds, target_names=CLASSES,
        output_dict=True, zero_division=0
    )
    metrics_data = {
        cls: {k: report[cls][k] for k in ["precision", "recall", "f1-score"]}
        for cls in CLASSES if cls in report
    }
    x = np.arange(len(CLASSES))
    width = 0.25

    fig, ax = plt.subplots(figsize=(14, 6))
    ax.bar(x - width, [metrics_data[c]["precision"] for c in CLASSES], width, label="Precision", color="#2196F3")
    ax.bar(x,         [metrics_data[c]["recall"]    for c in CLASSES], width, label="Recall",    color="#4CAF50")
    ax.bar(x + width, [metrics_data[c]["f1-score"]  for c in CLASSES], width, label="F1-Score",  color="#FF5722")

    ax.set_xticks(x)
    ax.set_xticklabels([c.replace("_", "\n") for c in CLASSES], fontsize=9)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Score", fontsize=12)
    ax.set_title("Per-Class Metrics: Precision, Recall, F1-Score", fontsize=14, fontweight="bold")
    ax.legend(fontsize=11)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {save_path}")


def evaluate(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)

    loaders = build_dataloaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
    )
    model = load_model(args.checkpoint, device)

    preds, labels, probs = run_inference(model, loaders["test"], device)

    # Classification report
    report = classification_report(
        labels, preds, target_names=CLASSES, zero_division=0
    )
    print("\nClassification Report:")
    print(report)
    with open(results_dir / "classification_report.txt", "w") as f:
        f.write(report)

    # Plots
    plot_confusion_matrix(labels, preds, results_dir / "confusion_matrix.png")
    plot_roc_curves(labels, probs, results_dir / "roc_curves.png")
    plot_per_class_metrics(labels, preds, results_dir / "per_class_metrics.png")

    print(f"\nAll evaluation outputs saved to {results_dir}/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir",    type=str, default="data/processed")
    parser.add_argument("--checkpoint",  type=str, default="checkpoints/best_model.pth")
    parser.add_argument("--batch_size",  type=int, default=32)
    parser.add_argument("--num_workers", type=int, default=4)
    args = parser.parse_args()
    evaluate(args)
