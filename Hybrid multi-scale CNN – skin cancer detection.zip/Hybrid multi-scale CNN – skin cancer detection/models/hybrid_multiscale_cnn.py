"""
models/hybrid_multiscale_cnn.py

Hybrid Multi-Scale Deep Learning Framework for Skin Cancer Detection.
Architecture:
  - Three parallel CNN branches (EfficientNet-B0/B2/B4) at different scales
  - Feature Pyramid for cross-scale communication
  - Attention-based feature fusion module
  - Classification head with dropout regularization
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from typing import List, Tuple


# ─────────────────────────────────────────────────────────────────────────────
# 1. Single-Scale CNN Branch (EfficientNet backbone)
# ─────────────────────────────────────────────────────────────────────────────

class CNNBranch(nn.Module):
    """
    Single EfficientNet backbone branch.
    Extracts features from one image scale.
    """

    BACKBONE_MAP = {
        128: "efficientnet_b0",  # lightweight for small scale
        224: "efficientnet_b2",  # balanced for medium scale
        320: "efficientnet_b4",  # powerful for large scale
    }

    def __init__(self, scale: int, pretrained: bool = True, out_features: int = 512):
        super().__init__()
        backbone_name = self.BACKBONE_MAP.get(scale, "efficientnet_b2")
        self.backbone = timm.create_model(
            backbone_name, pretrained=pretrained, num_classes=0, global_pool="avg"
        )
        in_features = self.backbone.num_features

        self.proj = nn.Sequential(
            nn.Linear(in_features, out_features),
            nn.BatchNorm1d(out_features),
            nn.GELU(),
            nn.Dropout(0.3),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.backbone(x)        # (B, in_features)
        feat = self.proj(feat)          # (B, out_features)
        return feat


# ─────────────────────────────────────────────────────────────────────────────
# 2. Channel Attention Module (Squeeze-and-Excitation style)
# ─────────────────────────────────────────────────────────────────────────────

class ChannelAttention(nn.Module):
    def __init__(self, in_dim: int, reduction: int = 8):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(in_dim, in_dim // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(in_dim // reduction, in_dim),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.gate(x)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Feature Fusion Module
# ─────────────────────────────────────────────────────────────────────────────

class FeatureFusion(nn.Module):
    """
    Attention-weighted fusion of multi-scale feature vectors.
    Learns to weight each scale's contribution dynamically.
    """

    def __init__(self, num_scales: int, feat_dim: int):
        super().__init__()
        self.num_scales = num_scales
        self.feat_dim = feat_dim

        # Per-scale attention
        self.scale_attention = nn.Sequential(
            nn.Linear(feat_dim * num_scales, num_scales),
            nn.Softmax(dim=-1),
        )

        # Channel attention on fused features
        self.channel_attn = ChannelAttention(feat_dim)

        # Final projection
        self.fusion_proj = nn.Sequential(
            nn.Linear(feat_dim, feat_dim),
            nn.LayerNorm(feat_dim),
            nn.GELU(),
        )

    def forward(self, features: List[torch.Tensor]) -> torch.Tensor:
        """
        features: list of (B, feat_dim) tensors, one per scale
        returns: (B, feat_dim) fused tensor
        """
        stacked = torch.stack(features, dim=1)           # (B, S, D)
        concat  = stacked.view(stacked.size(0), -1)      # (B, S*D)

        # Scale-level attention weights
        attn_weights = self.scale_attention(concat)       # (B, S)
        attn_weights = attn_weights.unsqueeze(-1)         # (B, S, 1)

        # Weighted sum across scales
        fused = (stacked * attn_weights).sum(dim=1)       # (B, D)

        # Channel attention
        fused = self.channel_attn(fused)

        return self.fusion_proj(fused)                    # (B, D)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Full Hybrid Multi-Scale Model
# ─────────────────────────────────────────────────────────────────────────────

class HybridMultiScaleCNN(nn.Module):
    """
    Complete Hybrid Multi-Scale CNN for skin cancer detection.

    Input : List of 3 image tensors at scales [128, 224, 320]
    Output: Class logits (B, num_classes)
    """

    def __init__(
        self,
        num_classes: int = 7,
        scales: List[int] = [128, 224, 320],
        feat_dim: int = 512,
        pretrained: bool = True,
        dropout: float = 0.4,
    ):
        super().__init__()
        self.scales = scales
        self.feat_dim = feat_dim

        # Parallel CNN branches
        self.branches = nn.ModuleList([
            CNNBranch(scale=s, pretrained=pretrained, out_features=feat_dim)
            for s in scales
        ])

        # Feature fusion
        self.fusion = FeatureFusion(num_scales=len(scales), feat_dim=feat_dim)

        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(feat_dim, 256),
            nn.BatchNorm1d(256),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.GELU(),
            nn.Dropout(dropout / 2),
            nn.Linear(128, num_classes),
        )

        self._init_classifier_weights()

    def _init_classifier_weights(self):
        for m in self.classifier.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x_list: List[torch.Tensor]) -> torch.Tensor:
        """
        x_list: [x_small, x_medium, x_large]
        Each x: (B, 3, H, W)
        """
        # Extract features from each branch in parallel
        branch_features = [branch(x) for branch, x in zip(self.branches, x_list)]

        # Fuse features with attention
        fused = self.fusion(branch_features)           # (B, feat_dim)

        # Classify
        logits = self.classifier(fused)                # (B, num_classes)
        return logits

    def get_feature_maps(self, x_list: List[torch.Tensor]) -> dict:
        """Returns intermediate features for visualization/GradCAM."""
        branch_features = [branch(x) for branch, x in zip(self.branches, x_list)]
        fused = self.fusion(branch_features)
        logits = self.classifier(fused)
        return {
            "branch_features": branch_features,
            "fused": fused,
            "logits": logits,
        }


# ─────────────────────────────────────────────────────────────────────────────
# 5. Model Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_model(
    num_classes: int = 7,
    scales: List[int] = [128, 224, 320],
    feat_dim: int = 512,
    pretrained: bool = True,
    dropout: float = 0.4,
) -> HybridMultiScaleCNN:
    model = HybridMultiScaleCNN(
        num_classes=num_classes,
        scales=scales,
        feat_dim=feat_dim,
        pretrained=pretrained,
        dropout=dropout,
    )
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Model: HybridMultiScaleCNN")
    print(f"  Total params     : {total_params:,}")
    print(f"  Trainable params : {trainable_params:,}")
    return model


if __name__ == "__main__":
    # Quick sanity check
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(num_classes=7, pretrained=False).to(device)

    # Simulate a batch of multi-scale inputs
    batch = [
        torch.randn(4, 3, 128, 128).to(device),
        torch.randn(4, 3, 224, 224).to(device),
        torch.randn(4, 3, 320, 320).to(device),
    ]
    out = model(batch)
    print(f"Output shape: {out.shape}")  # (4, 7)
    print("Model forward pass OK.")
