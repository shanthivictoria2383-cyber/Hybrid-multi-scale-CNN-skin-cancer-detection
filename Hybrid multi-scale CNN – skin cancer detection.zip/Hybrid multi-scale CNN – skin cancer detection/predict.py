"""
predict.py
Real-time inference on a single image or folder of images.

Usage:
    python predict.py --image path/to/image.jpg --checkpoint checkpoints/best_model.pth
    python predict.py --folder path/to/folder/  --checkpoint checkpoints/best_model.pth
"""

import argparse
import numpy as np
from pathlib import Path
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.patches as patches

import torch
import torch.nn.functional as F
import albumentations as A
from albumentations.pytorch import ToTensorV2

from data.dataset import CLASSES, IDX_TO_CLASS, SCALES
from models.hybrid_multiscale_cnn import build_model


# Colour palette for classes
CLASS_COLORS = {
    "Melanoma":              "#E53935",
    "Melanocytic_Nevi":      "#43A047",
    "Basal_Cell_Carcinoma":  "#FB8C00",
    "Actinic_Keratosis":     "#8E24AA",
    "Benign_Keratosis":      "#1E88E5",
    "Dermatofibroma":        "#00897B",
    "Vascular_Lesion":       "#F06292",
}

RISK_LEVEL = {
    "Melanoma":              ("HIGH RISK",   "#E53935"),
    "Basal_Cell_Carcinoma":  ("HIGH RISK",   "#E53935"),
    "Actinic_Keratosis":     ("MEDIUM RISK", "#FB8C00"),
    "Squamous_Cell_Carcinoma": ("HIGH RISK", "#E53935"),
    "Melanocytic_Nevi":      ("LOW RISK",    "#43A047"),
    "Benign_Keratosis":      ("LOW RISK",    "#43A047"),
    "Dermatofibroma":        ("LOW RISK",    "#43A047"),
    "Vascular_Lesion":       ("MEDIUM RISK", "#FB8C00"),
}


def load_model(checkpoint_path, device):
    model = build_model(num_classes=len(CLASSES), pretrained=False).to(device)
    ckpt  = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model


def preprocess_image(image_path):
    """Load and prepare multi-scale image tensors."""
    img = np.array(Image.open(image_path).convert("RGB"))
    tensors = []
    for size in SCALES:
        tf = A.Compose([
            A.Resize(size, size),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
        tensors.append(tf(image=img)["image"].unsqueeze(0))
    return tensors, img


@torch.no_grad()
def predict_single(model, image_path, device):
    tensors, raw_img = preprocess_image(image_path)
    tensors = [t.to(device) for t in tensors]
    logits  = model(tensors)
    probs   = F.softmax(logits, dim=-1).squeeze().cpu().numpy()
    pred_idx = int(np.argmax(probs))
    return {
        "predicted_class": CLASSES[pred_idx],
        "confidence":      float(probs[pred_idx]),
        "all_probs":       {CLASSES[i]: float(probs[i]) for i in range(len(CLASSES))},
        "raw_image":       raw_img,
    }


def visualize_prediction(image_path, result, save_path=None):
    raw_img    = result["raw_image"]
    pred_class = result["predicted_class"]
    confidence = result["confidence"]
    all_probs  = result["all_probs"]
    risk_label, risk_color = RISK_LEVEL.get(pred_class, ("UNKNOWN", "#9E9E9E"))

    fig = plt.figure(figsize=(14, 5))
    gs  = fig.add_gridspec(1, 3, width_ratios=[2, 2, 3], wspace=0.35)

    # ── Panel 1: Image ──
    ax1 = fig.add_subplot(gs[0])
    ax1.imshow(raw_img)
    ax1.set_title("Input Dermoscopic Image", fontsize=11, fontweight="bold")
    ax1.axis("off")
    # Colored border
    for spine in ax1.spines.values():
        spine.set_edgecolor(CLASS_COLORS.get(pred_class, "#333"))
        spine.set_linewidth(4)

    # ── Panel 2: Prediction box ──
    ax2 = fig.add_subplot(gs[1])
    ax2.axis("off")
    ax2.set_xlim(0, 1); ax2.set_ylim(0, 1)
    ax2.add_patch(patches.FancyBboxPatch(
        (0.05, 0.55), 0.9, 0.38, boxstyle="round,pad=0.03",
        fc=CLASS_COLORS.get(pred_class, "#333"), ec="none", alpha=0.15
    ))
    ax2.text(0.5, 0.88, "PREDICTION", ha="center", va="center",
             fontsize=10, color="#555", fontweight="bold")
    ax2.text(0.5, 0.73,
             pred_class.replace("_", "\n"), ha="center", va="center",
             fontsize=13, color=CLASS_COLORS.get(pred_class, "#333"), fontweight="bold")
    ax2.text(0.5, 0.59, f"Confidence: {confidence*100:.1f}%",
             ha="center", va="center", fontsize=11, color="#333")

    ax2.add_patch(patches.FancyBboxPatch(
        (0.2, 0.38), 0.6, 0.14, boxstyle="round,pad=0.02",
        fc=risk_color, ec="none", alpha=0.9
    ))
    ax2.text(0.5, 0.45, risk_label, ha="center", va="center",
             fontsize=12, color="white", fontweight="bold")

    ax2.text(0.5, 0.22,
             "⚠ This tool is for research only.\nConsult a dermatologist.",
             ha="center", va="center", fontsize=8.5, color="#888", style="italic")

    # ── Panel 3: Probability bars ──
    ax3 = fig.add_subplot(gs[2])
    sorted_items = sorted(all_probs.items(), key=lambda x: x[1], reverse=True)
    classes_sorted = [k.replace("_", " ") for k, _ in sorted_items]
    probs_sorted   = [v for _, v in sorted_items]
    colors_sorted  = [CLASS_COLORS.get(k, "#90CAF9") for k, _ in sorted_items]

    bars = ax3.barh(
        range(len(classes_sorted)), probs_sorted,
        color=colors_sorted, edgecolor="white", height=0.6
    )
    ax3.set_yticks(range(len(classes_sorted)))
    ax3.set_yticklabels(classes_sorted, fontsize=9)
    ax3.set_xlim(0, 1)
    ax3.set_xlabel("Probability", fontsize=10)
    ax3.set_title("Class Probabilities", fontsize=11, fontweight="bold")
    ax3.invert_yaxis()
    ax3.grid(axis="x", alpha=0.3)

    for i, (bar, prob) in enumerate(zip(bars, probs_sorted)):
        ax3.text(min(prob + 0.02, 0.95), i, f"{prob*100:.1f}%",
                 va="center", fontsize=9, color="#333")

    plt.suptitle("Hybrid Multi-Scale Skin Cancer Detection", fontsize=13,
                 fontweight="bold", y=1.02)

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved: {save_path}")
    plt.show()


def run_predict(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model  = load_model(args.checkpoint, device)
    out_dir = Path("results/predictions")
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.image:
        paths = [Path(args.image)]
    elif args.folder:
        paths = list(Path(args.folder).glob("*.jpg")) + \
                list(Path(args.folder).glob("*.png"))
    else:
        raise ValueError("Provide --image or --folder")

    for img_path in paths:
        print(f"\nProcessing: {img_path.name}")
        result = predict_single(model, img_path, device)
        print(f"  Predicted : {result['predicted_class']}")
        print(f"  Confidence: {result['confidence']*100:.1f}%")
        save_path = out_dir / f"{img_path.stem}_prediction.png"
        visualize_prediction(img_path, result, save_path=save_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Skin Cancer Prediction")
    parser.add_argument("--image",      type=str, help="Path to a single image")
    parser.add_argument("--folder",     type=str, help="Path to folder of images")
    parser.add_argument("--checkpoint", type=str, default="checkpoints/best_model.pth")
    args = parser.parse_args()
    run_predict(args)
