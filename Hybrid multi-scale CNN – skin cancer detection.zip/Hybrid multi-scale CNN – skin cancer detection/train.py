"""
train.py
Full training pipeline for Hybrid Multi-Scale CNN.
Supports: mixed precision, cosine LR schedule, early stopping, TensorBoard logging.

Usage:
    python train.py --data_dir data/processed --epochs 50 --batch_size 32
"""

import os
import argparse
import time
import json
import numpy as np
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from torch.cuda.amp import GradScaler, autocast
from torch.utils.tensorboard import SummaryWriter
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, classification_report, confusion_matrix
)
from tqdm import tqdm

from data.dataset import build_dataloaders, CLASSES
from models.hybrid_multiscale_cnn import build_model


# ─────────────────────────────────────────────────────────────────────────────
# Loss: Label-Smoothed Cross-Entropy + Class Weighting
# ─────────────────────────────────────────────────────────────────────────────

class FocalLoss(nn.Module):
    """Focal loss for handling class imbalance."""
    def __init__(self, weight=None, gamma=2.0, reduction="mean"):
        super().__init__()
        self.weight = weight
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        ce_loss = nn.CrossEntropyLoss(weight=self.weight, reduction="none")(inputs, targets)
        pt = torch.exp(-ce_loss)
        focal_loss = ((1 - pt) ** self.gamma) * ce_loss
        return focal_loss.mean() if self.reduction == "mean" else focal_loss


# ─────────────────────────────────────────────────────────────────────────────
# Metrics
# ─────────────────────────────────────────────────────────────────────────────

def compute_metrics(all_preds, all_labels, all_probs, num_classes):
    acc  = accuracy_score(all_labels, all_preds)
    prec = precision_score(all_labels, all_preds, average="weighted", zero_division=0)
    rec  = recall_score(all_labels, all_preds, average="weighted", zero_division=0)
    f1   = f1_score(all_labels, all_preds, average="weighted", zero_division=0)
    try:
        auc = roc_auc_score(
            all_labels, all_probs, multi_class="ovr", average="weighted"
        )
    except Exception:
        auc = 0.0
    return {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1, "roc_auc": auc}


# ─────────────────────────────────────────────────────────────────────────────
# One Epoch Train / Eval
# ─────────────────────────────────────────────────────────────────────────────

def run_epoch(model, loader, criterion, optimizer, scaler, device, mode="train"):
    is_train = mode == "train"
    model.train() if is_train else model.eval()

    total_loss = 0.0
    all_preds, all_labels, all_probs = [], [], []

    pbar = tqdm(loader, desc=f"  [{mode.upper()}]", leave=False)
    with torch.set_grad_enabled(is_train):
        for x_list, labels in pbar:
            x_list = [x.to(device, non_blocking=True) for x in x_list]
            labels = labels.to(device, non_blocking=True)

            if is_train:
                optimizer.zero_grad(set_to_none=True)

            with autocast(enabled=(scaler is not None)):
                logits = model(x_list)
                loss   = criterion(logits, labels)

            if is_train:
                if scaler is not None:
                    scaler.scale(loss).backward()
                    scaler.unscale_(optimizer)
                    nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optimizer.step()

            probs = torch.softmax(logits, dim=-1)
            preds = torch.argmax(probs, dim=-1)

            total_loss += loss.item() * labels.size(0)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs.detach().cpu().numpy())

            pbar.set_postfix({"loss": f"{loss.item():.4f}"})

    avg_loss = total_loss / len(loader.dataset)
    metrics  = compute_metrics(
        np.array(all_preds), np.array(all_labels),
        np.array(all_probs), num_classes=len(CLASSES)
    )
    metrics["loss"] = avg_loss
    return metrics


# ─────────────────────────────────────────────────────────────────────────────
# Main Training Loop
# ─────────────────────────────────────────────────────────────────────────────

def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")

    # Dataloaders
    loaders = build_dataloaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        val_split=0.15,
        test_split=0.15,
        num_workers=args.num_workers,
        seed=args.seed,
    )
    train_loader = loaders["train"]
    val_loader   = loaders["val"]
    test_loader  = loaders["test"]
    class_weights = loaders["class_weights"].to(device)

    # Model
    model = build_model(num_classes=len(CLASSES), pretrained=True).to(device)

    # Loss
    criterion = FocalLoss(weight=class_weights, gamma=2.0)

    # Optimizer: lower LR for pretrained backbone, higher for new heads
    backbone_params = []
    head_params     = []
    for name, param in model.named_parameters():
        if "backbone" in name:
            backbone_params.append(param)
        else:
            head_params.append(param)

    optimizer = optim.AdamW([
        {"params": backbone_params, "lr": args.lr * 0.1},
        {"params": head_params,     "lr": args.lr},
    ], weight_decay=1e-4)

    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=10, T_mult=2, eta_min=1e-6
    )

    scaler = GradScaler() if device.type == "cuda" else None

    # TensorBoard
    writer = SummaryWriter(log_dir=f"logs/run_{int(time.time())}")

    # Checkpoint dir
    ckpt_dir = Path("checkpoints")
    ckpt_dir.mkdir(exist_ok=True)

    best_val_f1   = 0.0
    patience_ctr  = 0
    history       = []

    print(f"\nStarting training for {args.epochs} epochs...\n")

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        print(f"Epoch {epoch}/{args.epochs}")

        train_metrics = run_epoch(model, train_loader, criterion, optimizer, scaler, device, "train")
        val_metrics   = run_epoch(model, val_loader,   criterion, None,      None,   device, "val")

        scheduler.step()

        elapsed = time.time() - t0
        print(
            f"  Train | Loss: {train_metrics['loss']:.4f}  "
            f"Acc: {train_metrics['accuracy']:.4f}  "
            f"F1: {train_metrics['f1']:.4f}  "
            f"AUC: {train_metrics['roc_auc']:.4f}"
        )
        print(
            f"  Val   | Loss: {val_metrics['loss']:.4f}  "
            f"Acc: {val_metrics['accuracy']:.4f}  "
            f"F1: {val_metrics['f1']:.4f}  "
            f"AUC: {val_metrics['roc_auc']:.4f}  "
            f"[{elapsed:.1f}s]"
        )

        # TensorBoard
        for k, v in train_metrics.items():
            writer.add_scalar(f"Train/{k}", v, epoch)
        for k, v in val_metrics.items():
            writer.add_scalar(f"Val/{k}", v, epoch)
        writer.add_scalar("LR", optimizer.param_groups[0]["lr"], epoch)

        history.append({"epoch": epoch, "train": train_metrics, "val": val_metrics})

        # Save best
        if val_metrics["f1"] > best_val_f1:
            best_val_f1 = val_metrics["f1"]
            patience_ctr = 0
            torch.save({
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "val_metrics": val_metrics,
            }, ckpt_dir / "best_model.pth")
            print(f"  ✓ Saved best model (Val F1: {best_val_f1:.4f})")
        else:
            patience_ctr += 1
            if patience_ctr >= args.patience:
                print(f"\nEarly stopping triggered after {epoch} epochs.")
                break

    # ─── Final Test Evaluation ───
    print("\n" + "="*60)
    print("FINAL TEST EVALUATION")
    print("="*60)
    ckpt = torch.load(ckpt_dir / "best_model.pth", map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])

    test_metrics = run_epoch(model, test_loader, criterion, None, None, device, "test")
    print(f"\nTest Results:")
    for k, v in test_metrics.items():
        print(f"  {k:<15}: {v:.4f}")

    # Save history
    with open("results/training_history.json", "w") as f:
        json.dump(history, f, indent=2)
    with open("results/test_metrics.json", "w") as f:
        json.dump(test_metrics, f, indent=2)

    writer.close()
    print("\nTraining complete. Results saved to results/")
    return model, test_metrics


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(description="Train Hybrid Multi-Scale CNN")
    parser.add_argument("--data_dir",    type=str, default="data/processed")
    parser.add_argument("--epochs",      type=int, default=50)
    parser.add_argument("--batch_size",  type=int, default=32)
    parser.add_argument("--lr",          type=float, default=1e-3)
    parser.add_argument("--patience",    type=int, default=10)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--seed",        type=int, default=42)
    return parser.parse_args()


if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    train(args)
