"""
utils/gradcam.py
GradCAM visualization for the hybrid model's CNN branches.
Shows which regions each scale focuses on.

Usage:
    python utils/gradcam.py --image path/to/image.jpg --checkpoint checkpoints/best_model.pth
"""

import argparse
import numpy as np
import matplotlib.pyplot as plt
import cv2
from pathlib import Path
from PIL import Image

import torch
import torch.nn.functional as F
import albumentations as A
from albumentations.pytorch import ToTensorV2

from data.dataset import CLASSES, SCALES
from models.hybrid_multiscale_cnn import build_model


class GradCAM:
    """GradCAM for a single CNN branch backbone."""

    def __init__(self, model, branch_idx: int):
        self.model      = model
        self.branch_idx = branch_idx
        self.gradients  = None
        self.activations = None
        self._register_hooks()

    def _register_hooks(self):
        branch   = self.model.branches[self.branch_idx]
        # Target last conv block of EfficientNet
        target   = list(branch.backbone.children())[-1]

        def forward_hook(module, input, output):
            self.activations = output.detach()

        def backward_hook(module, grad_in, grad_out):
            self.gradients = grad_out[0].detach()

        target.register_forward_hook(forward_hook)
        target.register_full_backward_hook(backward_hook)

    def generate(self, x_list, class_idx=None):
        self.model.eval()
        logits = self.model(x_list)

        if class_idx is None:
            class_idx = logits.argmax(dim=-1).item()

        self.model.zero_grad()
        logits[0, class_idx].backward()

        grads = self.gradients             # (1, C, H, W)
        acts  = self.activations           # (1, C, H, W)

        weights = grads.mean(dim=(2, 3), keepdim=True)  # (1, C, 1, 1)
        cam     = (weights * acts).sum(dim=1).squeeze()  # (H, W)
        cam     = F.relu(cam)
        cam     = cam.cpu().numpy()
        cam     = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, class_idx


def overlay_cam(image_np, cam, alpha=0.45):
    h, w = image_np.shape[:2]
    cam_resized = cv2.resize(cam, (w, h))
    heatmap     = cv2.applyColorMap(np.uint8(255 * cam_resized), cv2.COLORMAP_JET)
    heatmap     = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    overlay     = (1 - alpha) * image_np + alpha * heatmap
    return np.clip(overlay, 0, 255).astype(np.uint8)


def visualize_gradcam(image_path, checkpoint, save_path=None):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model  = build_model(num_classes=len(CLASSES), pretrained=False).to(device)
    ckpt   = torch.load(checkpoint, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])

    raw_img = np.array(Image.open(image_path).convert("RGB"))
    scale_names = ["Small (128)", "Medium (224)", "Large (320)"]

    tensors = []
    for size in SCALES:
        tf = A.Compose([
            A.Resize(size, size),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2(),
        ])
        tensors.append(tf(image=raw_img)["image"].unsqueeze(0).to(device))

    fig, axes = plt.subplots(2, len(SCALES), figsize=(5 * len(SCALES), 8))
    fig.suptitle("GradCAM – Attention Maps per Scale", fontsize=14, fontweight="bold")

    for i, (branch_idx, scale_name) in enumerate(zip(range(len(SCALES)), scale_names)):
        # Reload model for clean gradient graph
        model_fresh = build_model(num_classes=len(CLASSES), pretrained=False).to(device)
        model_fresh.load_state_dict(ckpt["model_state_dict"])
        gcam = GradCAM(model_fresh, branch_idx=branch_idx)

        try:
            cam, pred_idx = gcam.generate([t.clone().requires_grad_(True) for t in tensors])
        except Exception as e:
            print(f"GradCAM failed for branch {branch_idx}: {e}")
            continue

        size = SCALES[branch_idx]
        img_resized = cv2.resize(raw_img, (size, size))
        overlaid    = overlay_cam(img_resized, cam)

        axes[0, i].imshow(img_resized)
        axes[0, i].set_title(f"Input – {scale_name}", fontsize=10)
        axes[0, i].axis("off")

        axes[1, i].imshow(overlaid)
        axes[1, i].set_title(f"GradCAM – {scale_name}", fontsize=10)
        axes[1, i].axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved: {save_path}")
    plt.show()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image",      required=True)
    parser.add_argument("--checkpoint", default="checkpoints/best_model.pth")
    parser.add_argument("--save",       default=None)
    args = parser.parse_args()
    visualize_gradcam(args.image, args.checkpoint, save_path=args.save)
