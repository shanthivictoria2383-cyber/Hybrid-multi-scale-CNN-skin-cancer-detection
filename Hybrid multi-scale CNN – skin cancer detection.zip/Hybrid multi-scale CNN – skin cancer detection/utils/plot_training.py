"""
utils/plot_training.py
Plots training history curves from results/training_history.json

Usage:
    python utils/plot_training.py
"""

import json
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path


def plot_training_history(history_path="results/training_history.json", save_dir="results"):
    with open(history_path) as f:
        history = json.load(f)

    epochs       = [h["epoch"] for h in history]
    metrics_keys = ["loss", "accuracy", "f1", "roc_auc"]
    titles       = ["Loss", "Accuracy", "F1 Score", "ROC-AUC"]

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    axes = axes.flatten()

    for ax, key, title in zip(axes, metrics_keys, titles):
        train_vals = [h["train"][key] for h in history]
        val_vals   = [h["val"][key]   for h in history]

        ax.plot(epochs, train_vals, "b-o", markersize=3, linewidth=1.8, label="Train")
        ax.plot(epochs, val_vals,   "r-o", markersize=3, linewidth=1.8, label="Val")

        # Best val marker
        best_idx = (np.argmin(val_vals) if key == "loss" else np.argmax(val_vals))
        ax.axvline(epochs[best_idx], color="gray", linestyle="--", alpha=0.5)
        ax.scatter(epochs[best_idx], val_vals[best_idx], color="red", s=80, zorder=5,
                   label=f"Best Val ({val_vals[best_idx]:.4f})")

        ax.set_title(title, fontsize=13, fontweight="bold")
        ax.set_xlabel("Epoch", fontsize=11)
        ax.set_ylabel(title, fontsize=11)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)

    plt.suptitle("Training History – Hybrid Multi-Scale CNN", fontsize=14,
                 fontweight="bold", y=1.01)
    plt.tight_layout()

    save_path = Path(save_dir) / "training_curves.png"
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved: {save_path}")


if __name__ == "__main__":
    plot_training_history()
